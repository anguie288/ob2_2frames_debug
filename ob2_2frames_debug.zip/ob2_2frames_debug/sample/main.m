//
//  main.m
//  sample
//
//  Created by Angela on 2020-04-05.
//  Copyright © 2020 angela. All rights reserved.
//

#import <Foundation/Foundation.h>

void goodday (char *time){
    printf ("good %s\n", time);}

void allmsgs(void) {
    goodday("morning");goodday("afternoon");}

void greet (int count){
    for (int h = 0; h<count; h++){
        allmsgs();
        printf("greet two\n");}
}

int timestwo(int num){
    return num *2;
}

int timesrecur (int num){
    if (num ==0){
        return 0;}
    else {
        return 2+ timesrecur(num-1);
        }
}

int main(int argc, const char * argv[]) {
    
    // loops lesson
    //goodday ("time");
    //greet(2);
    
    int a = timestwo(3);
    int b = timesrecur(3);
    
    printf("timestwo: %d\n", a);
    printf("timesrec: %d\n", b);
    
    
    return 0;
}



